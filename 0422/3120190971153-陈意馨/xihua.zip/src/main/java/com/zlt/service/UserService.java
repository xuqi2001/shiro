package com.zlt.service;

import com.zlt.entity.User;

import java.util.List;

public interface UserService {
    public List<User> getAllUsers();
}
