package com.zlt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartSpring {
    public static void main(String []arg)
    {
        SpringApplication.run(StartSpring.class,arg);
    }
}