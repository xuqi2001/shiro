package com.zlt.entity;

import java.sql.Date;

public class User
{
    private int id;
    private  String username;
    private  String password;
    private  String nickname;
    private  String mobile;
    private  String email;
    private  String qq;
    private  String gender;
    private  String avatar;
    private  String user_type;
    private String reg_ip;
    private String login_count;
    private String remark;
    private String status;
    private String last_login_ip;
    private String last_login_time;
    private Date create_time;
    private Date update_time;

    public User(int id, String username) {
        this.id = id;
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getMobile() {
        return mobile;
    }

    public String getUsername() {
        return username;
    }

    public User(int id, String username, String password, String nickname, String mobile, String email, String qq, String gender, String avatar, String user_type, String reg_ip, String login_count, String remark, String status, String last_login_ip, String last_login_time, Date create_time, Date update_time) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.mobile = mobile;
        this.email = email;
        this.qq = qq;
        this.gender = gender;
        this.avatar = avatar;
        this.user_type = user_type;
        this.reg_ip = reg_ip;
        this.login_count = login_count;
        this.remark = remark;
        this.status = status;
        this.last_login_ip = last_login_ip;
        this.last_login_time = last_login_time;
        this.create_time = create_time;
        this.update_time = update_time;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getReg_ip() {
        return reg_ip;
    }

    public void setReg_ip(String reg_ip) {
        this.reg_ip = reg_ip;
    }

    public String getLogin_count() {
        return login_count;
    }

    public void setLogin_count(String login_count) {
        this.login_count = login_count;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLast_login_ip() {
        return last_login_ip;
    }

    public void setLast_login_ip(String last_login_ip) {
        this.last_login_ip = last_login_ip;
    }

    public String getLast_login_time() {
        return last_login_time;
    }

    public void setLast_login_time(String last_login_time) {
        this.last_login_time = last_login_time;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }
}
